import React, { useState, useRef } from 'react';
import { SettingsIcon } from './icons/SettingsIcon';
import { UploadIcon } from './icons/UploadIcon';
import { DownloadIcon } from './icons/DownloadIcon';
import ToggleSwitch from './ToggleSwitch';

interface SettingsMenuProps {
  isDarkMode: boolean;
  onToggleDarkMode: () => void;
  onManageCategories: () => void;
  onExport: () => void;
  onImport: (event: React.ChangeEvent<HTMLInputElement>) => void;
}

const SettingsMenu: React.FC<SettingsMenuProps> = ({ 
  isDarkMode, 
  onToggleDarkMode, 
  onManageCategories,
  onExport,
  onImport
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const importInputRef = useRef<HTMLInputElement>(null);

  const handleImportClick = () => {
    importInputRef.current?.click();
  };

  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="p-2 text-slate-500 hover:text-primary dark:hover:text-slate-200 rounded-full hover:bg-slate-100 dark:hover:bg-slate-700 transition-all"
        title="Settings"
      >
        <SettingsIcon className="h-6 w-6" />
      </button>

      {isOpen && (
        <div
          className="absolute right-0 mt-2 w-64 bg-white dark:bg-slate-800 rounded-lg shadow-2xl ring-1 ring-black ring-opacity-5 py-2 z-50 animate-fade-in"
          onMouseLeave={() => setIsOpen(false)}
        >
          <div className="px-4 py-3 border-b border-slate-200 dark:border-slate-700">
            <ToggleSwitch label="Dark Mode" enabled={isDarkMode} onChange={onToggleDarkMode} />
          </div>
          <div className="py-1">
             <button
                onClick={() => { onManageCategories(); setIsOpen(false); }}
                className="w-full text-left flex items-center gap-3 px-4 py-2 text-sm text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700"
              >
                {/* <ListBulletIcon className="h-5 w-5" /> */}
                <span>Manage Categories</span>
              </button>
          </div>
          <div className="border-t border-slate-200 dark:border-slate-700 py-1">
             <input
                type="file"
                ref={importInputRef}
                className="hidden"
                accept=".json"
                onChange={(e) => { onImport(e); setIsOpen(false); }}
              />
              <button
                onClick={handleImportClick}
                className="w-full text-left flex items-center gap-3 px-4 py-2 text-sm text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700"
              >
                <UploadIcon className="h-5 w-5" />
                <span>Import Data</span>
              </button>
              <button
                onClick={() => { onExport(); setIsOpen(false); }}
                className="w-full text-left flex items-center gap-3 px-4 py-2 text-sm text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700"
              >
                <DownloadIcon className="h-5 w-5" />
                <span>Export Data</span>
              </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default SettingsMenu;
