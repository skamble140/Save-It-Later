import React, { useState } from 'react';
import { XIcon } from './icons/XIcon';
import { PlusIcon } from './icons/PlusIcon';
import { TrashIcon } from './icons/TrashIcon';
import { Category } from '../types';

interface ManageCategoriesModalProps {
  initialCategories: Category[];
  onSave: (updatedCategories: Category[]) => void;
  onClose: () => void;
}

const ManageCategoriesModal: React.FC<ManageCategoriesModalProps> = ({ initialCategories, onSave, onClose }) => {
  const [categories, setCategories] = useState(initialCategories);
  const [newCategory, setNewCategory] = useState('');

  const handleAddCategory = () => {
    if (newCategory.trim() && !categories.includes(newCategory.trim() as Category)) {
      setCategories([...categories, newCategory.trim() as Category]);
      setNewCategory('');
    }
  };

  const handleDeleteCategory = (categoryToDelete: Category) => {
    // Prevent deleting 'Other' as a fallback category
    if (categoryToDelete === 'Other') {
        alert("The 'Other' category cannot be deleted.");
        return;
    }
    setCategories(categories.filter(c => c !== categoryToDelete));
  };
  
  const handleSave = () => {
    onSave(categories);
    onClose();
  }

  return (
    <div 
        className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in"
        onClick={onClose}
    >
      <div 
        className="bg-white dark:bg-slate-800 rounded-2xl shadow-2xl w-full max-w-md p-6 md:p-8 space-y-6 animate-slide-up"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex justify-between items-center">
          <h2 className="text-2xl font-bold text-slate-800 dark:text-slate-100">Manage Categories</h2>
          <button onClick={onClose} className="p-2 text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 rounded-full hover:bg-slate-100 dark:hover:bg-slate-700 transition-all">
            <XIcon className="h-6 w-6" />
          </button>
        </div>
        
        <div className="space-y-3 max-h-60 overflow-y-auto pr-2">
            {categories.map(category => (
                <div key={category} className="flex justify-between items-center bg-slate-100 dark:bg-slate-700/50 p-3 rounded-lg">
                    <span className="font-medium text-slate-600 dark:text-slate-300">{category}</span>
                    {category !== 'Other' && (
                        <button onClick={() => handleDeleteCategory(category)} className="p-1 text-slate-500 hover:text-red-500 rounded-full" title={`Delete ${category}`}>
                            <TrashIcon className="h-4 w-4" />
                        </button>
                    )}
                </div>
            ))}
        </div>

        <div className="flex gap-2">
            <input 
                type="text"
                value={newCategory}
                onChange={(e) => setNewCategory(e.target.value)}
                placeholder="New category name"
                className="flex-grow px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
            />
            <button onClick={handleAddCategory} className="p-3 bg-primary text-white rounded-lg hover:bg-primary/90 disabled:bg-slate-400" disabled={!newCategory.trim()}>
                <PlusIcon className="h-5 w-5" />
            </button>
        </div>
        
        <div className="flex gap-4 !mt-8">
            <button 
                onClick={onClose} 
                className="w-full px-6 py-3 bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-100 font-semibold rounded-lg hover:bg-slate-300 dark:hover:bg-slate-600 focus:outline-none transition-all"
            >
                Cancel
            </button>
            <button 
                onClick={handleSave} 
                className="w-full px-6 py-3 bg-primary text-white font-semibold rounded-lg shadow-md hover:bg-primary/90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary transition-all"
            >
                Save Changes
            </button>
        </div>
      </div>
    </div>
  );
};

export default ManageCategoriesModal;
