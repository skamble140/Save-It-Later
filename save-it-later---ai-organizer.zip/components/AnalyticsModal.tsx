import React from 'react';
import { XIcon } from './icons/XIcon';

interface AnalyticsModalProps {
  data: {
    total: number;
    favorites: number;
    archived: number;
    byCategory: Record<string, number>;
  };
  onClose: () => void;
}

const AnalyticsModal: React.FC<AnalyticsModalProps> = ({ data, onClose }) => {
  return (
    <div 
        className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in"
        onClick={onClose}
    >
      <div 
        className="bg-white dark:bg-slate-800 rounded-2xl shadow-2xl w-full max-w-md p-6 md:p-8 space-y-6 animate-slide-up"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex justify-between items-center">
          <h2 className="text-2xl font-bold text-slate-800 dark:text-slate-100">Analytics</h2>
          <button onClick={onClose} className="p-2 text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 rounded-full hover:bg-slate-100 dark:hover:bg-slate-700 transition-all">
            <XIcon className="h-6 w-6" />
          </button>
        </div>
        
        <div className="grid grid-cols-3 gap-4 text-center">
            <div>
                <p className="text-3xl font-bold text-primary">{data.total}</p>
                <p className="text-sm text-slate-500 dark:text-slate-400">Total Links</p>
            </div>
            <div>
                <p className="text-3xl font-bold text-amber-500">{data.favorites}</p>
                <p className="text-sm text-slate-500 dark:text-slate-400">Favorites</p>
            </div>
            <div>
                <p className="text-3xl font-bold text-slate-600 dark:text-slate-300">{data.archived}</p>
                <p className="text-sm text-slate-500 dark:text-slate-400">Archived</p>
            </div>
        </div>
        
        <div>
            <h3 className="text-lg font-semibold mb-3 text-slate-700 dark:text-slate-200">Active Links by Category</h3>
            <div className="space-y-2">
                {Object.entries(data.byCategory).length > 0 ? Object.entries(data.byCategory)
                    .sort(([, a], [, b]) => b - a)
                    .map(([category, count]) => (
                    <div key={category} className="flex justify-between items-center bg-slate-100 dark:bg-slate-700/50 p-3 rounded-lg">
                        <span className="font-medium text-slate-600 dark:text-slate-300">{category}</span>
                        <span className="font-bold text-slate-800 dark:text-slate-100">{count}</span>
                    </div>
                )) : (
                    <p className="text-slate-500 dark:text-slate-400 text-center py-4">No active links to analyze.</p>
                )}
            </div>
        </div>
        
        <button 
            onClick={onClose} 
            className="w-full mt-4 px-6 py-3 bg-primary text-white font-semibold rounded-lg shadow-md hover:bg-primary/90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary transition-all"
        >
            Close
        </button>
      </div>
    </div>
  );
};

export default AnalyticsModal;
