import React, { useState, useRef, useEffect } from 'react';
import { BookmarkIcon } from './icons/BookmarkIcon';
import SettingsMenu from './SettingsMenu';

interface HeaderProps {
  appName: string;
  onAppNameChange: (newName: string) => void;
  isDarkMode: boolean;
  onToggleDarkMode: () => void;
  onManageCategories: () => void;
  onExport: () => void;
  onImport: (event: React.ChangeEvent<HTMLInputElement>) => void;
}

const Header: React.FC<HeaderProps> = ({ appName, onAppNameChange, ...settingsProps }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [currentName, setCurrentName] = useState(appName);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setCurrentName(appName);
  }, [appName]);

  useEffect(() => {
    if (isEditing) {
      inputRef.current?.focus();
      inputRef.current?.select();
    }
  }, [isEditing]);
  
  const handleSave = () => {
    if (currentName.trim()) {
      onAppNameChange(currentName.trim());
    } else {
      setCurrentName(appName); // Revert if empty
    }
    setIsEditing(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleSave();
    } else if (e.key === 'Escape') {
      setCurrentName(appName);
      setIsEditing(false);
    }
  };

  return (
    <header className="bg-white/80 dark:bg-slate-900/80 backdrop-blur-lg sticky top-0 z-40 border-b border-slate-200 dark:border-slate-700">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center py-4">
          <div className="flex items-center gap-3">
            <BookmarkIcon className="h-8 w-8 text-primary" />
            {isEditing ? (
              <input
                ref={inputRef}
                type="text"
                value={currentName}
                onChange={(e) => setCurrentName(e.target.value)}
                onBlur={handleSave}
                onKeyDown={handleKeyDown}
                className="text-2xl font-bold bg-transparent border-b-2 border-primary focus:outline-none text-slate-800 dark:text-slate-100 tracking-tight w-48"
              />
            ) : (
              <h1 
                className="text-2xl font-bold text-slate-800 dark:text-slate-100 tracking-tight cursor-pointer hover:bg-slate-200 dark:hover:bg-slate-700 px-2 rounded-md"
                onClick={() => setIsEditing(true)}
                title="Click to edit name"
              >
                {appName}
              </h1>
            )}
          </div>
          <div className="flex items-center gap-4">
            <SettingsMenu {...settingsProps} />
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
