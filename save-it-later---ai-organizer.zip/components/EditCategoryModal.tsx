import React, { useState } from 'react';
import { LinkItem, Category } from '../types';
import { XIcon } from './icons/XIcon';
import { PlusIcon } from './icons/PlusIcon';

interface EditCategoryModalProps {
  link: LinkItem;
  categories: Category[];
  onClose: () => void;
  onSave: (linkId: string, newCategory: Category) => void;
  onAddNewCategory: (newCategory: Category) => void;
}

const EditCategoryModal: React.FC<EditCategoryModalProps> = ({ link, categories, onClose, onSave, onAddNewCategory }) => {
  const [selectedCategory, setSelectedCategory] = useState<Category>(link.category);
  const [newCategory, setNewCategory] = useState('');

  const handleAddNewCategory = () => {
    if (newCategory.trim() && !categories.includes(newCategory.trim())) {
      const newCat = newCategory.trim();
      onAddNewCategory(newCat);
      setSelectedCategory(newCat);
      setNewCategory('');
    }
  };
  
  const handleSave = () => {
      onSave(link.id, selectedCategory);
  }

  return (
    <div 
        className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in"
        onClick={onClose}
    >
      <div 
        className="bg-white dark:bg-slate-800 rounded-2xl shadow-2xl w-full max-w-md p-6 md:p-8 space-y-6 animate-slide-up"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex justify-between items-center">
          <h2 className="text-2xl font-bold text-slate-800 dark:text-slate-100">Edit Category</h2>
          <button onClick={onClose} className="p-2 text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 rounded-full hover:bg-slate-100 dark:hover:bg-slate-700 transition-all">
            <XIcon className="h-6 w-6" />
          </button>
        </div>
        
        <p className="text-slate-500 dark:text-slate-400">Select a new category for <strong className="text-slate-700 dark:text-slate-200">{link.title}</strong></p>

        <div className="space-y-2 max-h-48 overflow-y-auto pr-2">
            {categories.filter(c => c !== 'All' && c !== 'Favorites' && c !== 'Archive').map(category => (
                <button 
                    key={category} 
                    onClick={() => setSelectedCategory(category)}
                    className={`w-full text-left p-3 rounded-lg transition-colors ${selectedCategory === category ? 'bg-primary text-white font-semibold' : 'bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600'}`}
                >
                    {category}
                </button>
            ))}
        </div>

        <div>
            <h3 className="text-lg font-semibold mb-2 text-slate-700 dark:text-slate-200">Add New Category</h3>
            <div className="flex gap-2">
                <input 
                    type="text"
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value)}
                    placeholder="New category name"
                    className="flex-grow px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                />
                <button onClick={handleAddNewCategory} className="p-3 bg-primary text-white rounded-lg hover:bg-primary/90 disabled:bg-slate-400" disabled={!newCategory.trim() || categories.includes(newCategory.trim())}>
                    <PlusIcon className="h-5 w-5" />
                </button>
            </div>
        </div>

        <div className="flex gap-4 !mt-8">
            <button 
                onClick={onClose} 
                className="w-full px-6 py-3 bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-100 font-semibold rounded-lg hover:bg-slate-300 dark:hover:bg-slate-600 focus:outline-none transition-all"
            >
                Cancel
            </button>
            <button 
                onClick={handleSave} 
                className="w-full px-6 py-3 bg-primary text-white font-semibold rounded-lg shadow-md hover:bg-primary/90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary transition-all"
            >
                Save
            </button>
        </div>
      </div>
    </div>
  );
};

export default EditCategoryModal;
