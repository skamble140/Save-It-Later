import React, { useState, useRef, useEffect } from 'react';
import { PlusIcon } from './icons/PlusIcon';
import { SpinnerIcon } from './icons/SpinnerIcon';

interface LinkInputFormProps {
  onAddLink: (url: string) => void;
  isLoading: boolean;
}

const LinkInputForm: React.FC<LinkInputFormProps> = ({ onAddLink, isLoading }) => {
  const [url, setUrl] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!isLoading) {
      setUrl('');
    }
  }, [isLoading]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (url.trim()) {
      onAddLink(url);
    }
  };

  const isValidUrl = (urlString: string) => {
    try { 
      // Use a more robust regex for URL validation
      const pattern = new RegExp('^(https?:\\/\\/)?'+ // protocol
        '((([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.)+[a-z]{2,}|'+ // domain name
        '((\\d{1,3}\\.){3}\\d{1,3}))'+ // OR ip (v4) address
        '(\\:\\d+)?(\\/[-a-z\\d%_.~+]*)*'+ // port and path
        '(\\?[;&a-z\\d%_.~+=-]*)?'+ // query string
        '(\\#[-a-z\\d_]*)?$','i'); // fragment locator
      return !!pattern.test(urlString);
    }
    catch(e){ 
      return false; 
    }
  }

  return (
    <form onSubmit={handleSubmit} className="mb-8">
      <div className="relative">
        <input
          ref={inputRef}
          type="url"
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          placeholder="Paste a URL to save..."
          disabled={isLoading}
          className="w-full pl-5 pr-20 py-4 text-lg bg-white dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:ring-4 focus:ring-primary/20 focus:border-primary transition-all shadow-lg"
        />
        <button
          type="submit"
          disabled={isLoading || !isValidUrl(url)}
          className="absolute inset-y-0 right-0 m-2 px-5 flex items-center gap-2 bg-primary text-white font-semibold rounded-lg shadow-md hover:bg-primary/90 disabled:bg-slate-400 disabled:cursor-not-allowed transition-all"
        >
          {isLoading ? (
            <>
              <SpinnerIcon className="h-5 w-5 animate-spin" />
              <span>Saving...</span>
            </>
          ) : (
            <>
              <PlusIcon className="h-5 w-5" />
              <span>Save Link</span>
            </>
          )}
        </button>
      </div>
    </form>
  );
};

export default LinkInputForm;
