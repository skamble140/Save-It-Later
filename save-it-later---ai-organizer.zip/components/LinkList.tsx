
import React from 'react';
import { LinkItem, Filter } from '../types';
import LinkCard from './LinkCard';

interface LinkListProps {
  links: LinkItem[];
  onDelete: (id: string) => void;
  onToggleFavorite: (id: string) => void;
  onToggleArchive: (id: string) => void;
  onEditCategory: (id: string) => void;
  onEditNotes: (id: string) => void;
  isLoading: boolean;
  viewMode: 'grid' | 'list';
  // FIX: Changed type to allow custom category strings as filters.
  activeFilter: Filter | string;
}

const SkeletonCard: React.FC = () => (
    <div className="bg-white dark:bg-slate-800 rounded-lg shadow-md overflow-hidden animate-pulse">
        <div className="h-48 bg-slate-300 dark:bg-slate-700"></div>
        <div className="p-4 space-y-3">
            <div className="h-6 bg-slate-300 dark:bg-slate-700 rounded w-3/4"></div>
            <div className="h-4 bg-slate-300 dark:bg-slate-700 rounded"></div>
            <div className="h-4 bg-slate-300 dark:bg-slate-700 rounded w-5/6"></div>
            <div className="flex flex-wrap gap-2 pt-2">
                <div className="h-6 w-20 bg-slate-300 dark:bg-slate-700 rounded-full"></div>
                <div className="h-6 w-24 bg-slate-300 dark:bg-slate-700 rounded-full"></div>
            </div>
        </div>
    </div>
);

// FIX: Changed type to allow custom category strings as filters.
const EmptyState: React.FC<{ filter: Filter | string }> = ({ filter }) => {
  const messages: Record<string, { title: string; body: string }> = {
    All: { title: 'No links saved yet', body: 'Save your first link to get started!' },
    Favorites: { title: 'No favorites yet', body: 'Click the star icon on a link to add it here.' },
    Archive: { title: 'The archive is empty', body: 'Archived links will appear here.' },
  };
  
  const defaultMessage = { title: `No links in ${filter}`, body: `Saved links in the '${filter}' category will appear here.`};
  const message = messages[filter] || defaultMessage;

  return (
    <div className="text-center py-16 px-6 bg-white dark:bg-slate-800 rounded-lg shadow-md col-span-1 md:col-span-2 lg:col-span-3">
      <h3 className="text-xl font-semibold text-slate-700 dark:text-slate-200">{message.title}</h3>
      <p className="text-slate-500 dark:text-slate-400 mt-2">{message.body}</p>
    </div>
  );
};


const LinkList: React.FC<LinkListProps> = ({ links, onDelete, onToggleFavorite, onToggleArchive, onEditCategory, onEditNotes, isLoading, viewMode, activeFilter }) => {
  if (isLoading && links.length === 0) {
      return (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-6">
              <SkeletonCard />
              <SkeletonCard />
              <SkeletonCard />
          </div>
      )
  }

  if (!links.length && !isLoading) {
    return (
        <div className="mt-6">
            <EmptyState filter={activeFilter} />
        </div>
    );
  }

  const containerClasses = viewMode === 'grid'
    ? "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
    : "flex flex-col space-y-4";

  return (
    <div className={`${containerClasses} mt-6`}>
       {isLoading && <SkeletonCard />}
      {links.map((link, index) => (
        <div key={link.id} className="animate-slide-up" style={{ animationDelay: `${index * 50}ms` }}>
            <LinkCard 
                link={link} 
                onDelete={onDelete} 
                onToggleFavorite={onToggleFavorite}
                onToggleArchive={onToggleArchive}
                onEditCategory={onEditCategory}
                onEditNotes={onEditNotes}
                viewMode={viewMode}
            />
        </div>
      ))}
    </div>
  );
};

export default LinkList;
