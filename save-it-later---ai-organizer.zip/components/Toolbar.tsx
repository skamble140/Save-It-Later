import React from 'react';
import { Filter } from '../types';
import FilterTabs from './FilterTabs';
import SearchBar from './SearchBar';
import { GridIcon } from './icons/GridIcon';
import { ListIcon } from './icons/ListIcon';
import { ChartBarIcon } from './icons/ChartBarIcon';

interface ToolbarProps {
  filters: (Filter | string)[];
  activeFilter: Filter | string;
  onSelectFilter: (filter: Filter | string) => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  viewMode: 'grid' | 'list';
  onViewModeChange: (mode: 'grid' | 'list') => void;
  onOpenAnalytics: () => void;
}

const Toolbar: React.FC<ToolbarProps> = ({
  filters,
  activeFilter,
  onSelectFilter,
  searchQuery,
  onSearchChange,
  viewMode,
  onViewModeChange,
  onOpenAnalytics,
}) => {
  return (
    <div className="mb-6 space-y-4 md:space-y-0 md:flex md:justify-between md:items-center">
      <FilterTabs filters={filters} activeFilter={activeFilter} onSelectFilter={onSelectFilter} />
      <div className="flex items-center gap-2">
        <SearchBar value={searchQuery} onChange={onSearchChange} />
        <div className="flex items-center bg-slate-200 dark:bg-slate-700 rounded-lg p-1">
          <button onClick={() => onViewModeChange('grid')} className={`p-2 rounded-md transition-colors ${viewMode === 'grid' ? 'bg-white dark:bg-slate-800 text-primary shadow' : 'text-slate-500 hover:bg-slate-300/50'}`} title="Grid View">
            <GridIcon className="h-5 w-5" />
          </button>
          <button onClick={() => onViewModeChange('list')} className={`p-2 rounded-md transition-colors ${viewMode === 'list' ? 'bg-white dark:bg-slate-800 text-primary shadow' : 'text-slate-500 hover:bg-slate-300/50'}`} title="List View">
            <ListIcon className="h-5 w-5" />
          </button>
        </div>
        <button onClick={onOpenAnalytics} className="p-3 bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-300/50 dark:hover:bg-slate-600/50 rounded-lg transition-colors" title="View Analytics">
            <ChartBarIcon className="h-5 w-5" />
        </button>
      </div>
    </div>
  );
};

export default Toolbar;
