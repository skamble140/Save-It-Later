import React from 'react';
import { Filter } from '../types';

interface FilterTabsProps {
  filters: (Filter | string)[];
  activeFilter: Filter | string;
  onSelectFilter: (filter: Filter | string) => void;
}

const FilterTabs: React.FC<FilterTabsProps> = ({ filters, activeFilter, onSelectFilter }) => {
  return (
    <div className="flex space-x-1 p-1 bg-slate-200 dark:bg-slate-700 rounded-lg overflow-x-auto">
      {filters.map(filter => (
        <button
          key={filter}
          onClick={() => onSelectFilter(filter)}
          className={`px-4 py-2 text-sm font-semibold rounded-md transition-colors duration-200 whitespace-nowrap ${
            activeFilter === filter
              ? 'bg-white dark:bg-slate-800 text-primary shadow'
              : 'text-slate-600 dark:text-slate-300 hover:bg-slate-300/50 dark:hover:bg-slate-600/50'
          }`}
        >
          {filter}
        </button>
      ))}
    </div>
  );
};

export default FilterTabs;
