import React, { useState } from 'react';
import { LinkItem } from '../types';
import { ExternalLinkIcon } from './icons/ExternalLinkIcon';
import { CopyIcon } from './icons/CopyIcon';
import { TrashIcon } from './icons/TrashIcon';
import { CheckIcon } from './icons/CheckIcon';
import { StarIcon } from './icons/StarIcon';
import { ArchiveIcon } from './icons/ArchiveIcon';
import { DocumentTextIcon } from './icons/DocumentTextIcon';

interface LinkCardProps {
  link: LinkItem;
  onDelete: (id: string) => void;
  onToggleFavorite: (id: string) => void;
  onToggleArchive: (id: string) => void;
  onEditCategory: (id: string) => void;
  onEditNotes: (id: string) => void;
  viewMode: 'grid' | 'list';
}

const categoryColors: { [key: string]: string } = {
  Article: 'bg-sky-100 text-sky-800 dark:bg-sky-900/50 dark:text-sky-300',
  Video: 'bg-red-100 text-red-800 dark:bg-red-900/50 dark:text-red-300',
  Product: 'bg-green-100 text-green-800 dark:bg-green-900/50 dark:text-green-300',
  Social: 'bg-indigo-100 text-indigo-800 dark:bg-indigo-900/50 dark:text-indigo-300',
  Other: 'bg-slate-100 text-slate-800 dark:bg-slate-700 dark:text-slate-300',
};

const getCategoryColor = (category: string) => {
    return categoryColors[category] || 'bg-purple-100 text-purple-800 dark:bg-purple-900/50 dark:text-purple-300';
}


const LinkCard: React.FC<LinkCardProps> = ({ link, onDelete, onToggleFavorite, onToggleArchive, onEditCategory, onEditNotes, viewMode }) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(link.url);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const CardContent = () => (
    <>
      <div className={`p-5 ${viewMode === 'list' ? 'flex flex-col flex-grow' : 'flex flex-col flex-grow'}`}>
        <div className="flex justify-between items-start mb-2">
          <button 
            onClick={() => onEditCategory(link.id)} 
            className={`text-xs font-semibold px-2.5 py-1 rounded-full transition-transform hover:scale-105 ${getCategoryColor(link.category)}`}
            title="Edit Category"
          >
            {link.category}
          </button>
        </div>
        <h3 className="text-lg font-bold text-slate-800 dark:text-slate-100 mb-2 leading-tight flex items-center gap-2">
          {link.title}
          {/* FIX: Wrapped DocumentTextIcon in a span to apply the title attribute, as it's not a valid prop on the SVG component. */}
          {link.notes && <span title="Has notes"><DocumentTextIcon className="h-4 w-4 text-slate-400 flex-shrink-0" /></span>}
        </h3>
        <p className="text-slate-500 dark:text-slate-400 text-sm flex-grow mb-4">{link.description}</p>
        
        <div className="flex flex-wrap gap-2 mb-4">
          {link.tags.map(tag => (
            <span key={tag} className="bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 text-xs font-medium px-2.5 py-1 rounded-full">
              #{tag}
            </span>
          ))}
        </div>
      </div>
      <div className={`p-5 pt-0 border-t border-slate-200 dark:border-slate-700 flex justify-between items-center gap-2 ${viewMode === 'list' ? 'mt-auto' : ''}`}>
        <a href={link.url} target="_blank" rel="noopener noreferrer" className="truncate text-sm text-slate-400 hover:text-primary transition-colors">
          {new URL(link.url).hostname}
        </a>
        <div className="flex items-center gap-1 sm:gap-2">
          <button onClick={() => onToggleFavorite(link.id)} className={`p-2 text-slate-500 rounded-full transition-all ${link.isFavorite ? 'text-amber-500 hover:text-amber-600' : 'hover:text-amber-500 dark:hover:text-amber-400 hover:bg-slate-100 dark:hover:bg-slate-700'}`} title={link.isFavorite ? 'Unfavorite' : 'Favorite'}>
              <StarIcon className={`h-5 w-5 ${link.isFavorite ? 'fill-current' : ''}`} />
          </button>
           <button onClick={() => onToggleArchive(link.id)} className="p-2 text-slate-500 hover:text-primary dark:hover:text-slate-200 rounded-full hover:bg-slate-100 dark:hover:bg-slate-700 transition-all" title={link.isArchived ? 'Unarchive' : 'Archive'}>
              <ArchiveIcon className="h-5 w-5" />
          </button>
           <button onClick={() => onEditNotes(link.id)} className="p-2 text-slate-500 hover:text-primary dark:hover:text-slate-200 rounded-full hover:bg-slate-100 dark:hover:bg-slate-700 transition-all" title="Add/Edit Notes">
              <DocumentTextIcon className="h-5 w-5" />
          </button>
          <a href={link.url} target="_blank" rel="noopener noreferrer" className="p-2 text-slate-500 hover:text-primary dark:hover:text-slate-200 rounded-full hover:bg-slate-100 dark:hover:bg-slate-700 transition-all" title="Open Link">
            <ExternalLinkIcon className="h-5 w-5" />
          </a>
          <button onClick={handleCopy} className="p-2 text-slate-500 hover:text-primary dark:hover:text-slate-200 rounded-full hover:bg-slate-100 dark:hover:bg-slate-700 transition-all" title="Copy Link">
            {copied ? <CheckIcon className="h-5 w-5 text-green-500" /> : <CopyIcon className="h-5 w-5" />}
          </button>
          <button onClick={() => onDelete(link.id)} className="p-2 text-slate-500 hover:text-red-500 dark:hover:text-red-400 rounded-full hover:bg-red-100 dark:hover:bg-red-900/50 transition-all" title="Delete Link">
            <TrashIcon className="h-5 w-5" />
          </button>
        </div>
      </div>
    </>
  );

  if (viewMode === 'list') {
    return (
      <div className="bg-white dark:bg-slate-800 rounded-2xl shadow-lg overflow-hidden flex transition-shadow duration-300 hover:shadow-2xl">
        <img src={link.image} alt={link.title} className="w-32 md:w-48 h-full object-cover hidden sm:block" />
        <div className="flex-grow flex flex-col">
            <CardContent />
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white dark:bg-slate-800 rounded-2xl shadow-lg overflow-hidden h-full flex flex-col transition-transform duration-300 hover:scale-[1.02] hover:shadow-2xl">
      <img src={link.image} alt={link.title} className="w-full h-48 object-cover" />
      <CardContent />
    </div>
  );
};

export default LinkCard;