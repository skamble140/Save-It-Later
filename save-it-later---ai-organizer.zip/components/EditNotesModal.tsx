import React, { useState } from 'react';
import { LinkItem } from '../types';
import { XIcon } from './icons/XIcon';

interface EditNotesModalProps {
  link: LinkItem;
  onClose: () => void;
  onSave: (linkId: string, newNotes: string) => void;
}

const EditNotesModal: React.FC<EditNotesModalProps> = ({ link, onClose, onSave }) => {
  const [notes, setNotes] = useState(link.notes || '');

  const handleSave = () => {
    onSave(link.id, notes);
  };

  return (
    <div 
        className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in"
        onClick={onClose}
    >
      <div 
        className="bg-white dark:bg-slate-800 rounded-2xl shadow-2xl w-full max-w-lg p-6 md:p-8 space-y-6 animate-slide-up"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex justify-between items-center">
          <h2 className="text-2xl font-bold text-slate-800 dark:text-slate-100">Add/Edit Notes</h2>
          <button onClick={onClose} className="p-2 text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 rounded-full hover:bg-slate-100 dark:hover:bg-slate-700 transition-all">
            <XIcon className="h-6 w-6" />
          </button>
        </div>
        
        <p className="text-slate-500 dark:text-slate-400">Notes for: <strong className="text-slate-700 dark:text-slate-200 truncate">{link.title}</strong></p>

        <div>
            <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Write your notes here..."
                rows={8}
                className="w-full p-3 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
            />
        </div>

        <div className="flex gap-4 !mt-8">
            <button 
                onClick={onClose} 
                className="w-full px-6 py-3 bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-100 font-semibold rounded-lg hover:bg-slate-300 dark:hover:bg-slate-600 focus:outline-none transition-all"
            >
                Cancel
            </button>
            <button 
                onClick={handleSave} 
                className="w-full px-6 py-3 bg-primary text-white font-semibold rounded-lg shadow-md hover:bg-primary/90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary transition-all"
            >
                Save Notes
            </button>
        </div>
      </div>
    </div>
  );
};

export default EditNotesModal;
