
export type Category = string;

export type Filter = 'All' | 'Favorites' | 'Archive';

export interface LinkItem {
  id: string;
  url: string;
  title: string;
  description: string;
  image: string;
  category: Category;
  tags: string[];
  isFavorite: boolean;
  isArchived: boolean;
  notes: string;
}
