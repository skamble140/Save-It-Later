import { Filter, LinkItem, Category } from './types';

export const INITIAL_CATEGORIES: Category[] = ['Article', 'Video', 'Product', 'Social', 'Other'];
export const FILTERS: Filter[] = ['All', 'Favorites', 'Archive'];


export const initialLinks: LinkItem[] = [
  {
    id: '1',
    url: 'https://react.dev/',
    title: 'React - A JavaScript library for building user interfaces',
    description: 'The library for web and native user interfaces. Build user interfaces out of individual pieces called components written in JavaScript.',
    image: 'https://picsum.photos/seed/react/600/400',
    category: 'Article',
    tags: ['react', 'javascript', 'ui'],
    isFavorite: true,
    isArchived: false,
    notes: 'This is the official documentation. Great for learning about Hooks and Suspense.',
  },
  {
    id: '2',
    url: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    title: 'A Great Music Video',
    description: 'An iconic music video from the 80s that has become a cultural phenomenon online. It\'s known for its catchy tune and memorable dance moves.',
    image: 'https://picsum.photos/seed/music/600/400',
    category: 'Video',
    tags: ['music', 'video', '80s'],
    isFavorite: false,
    isArchived: false,
    notes: '',
  },
   {
    id: '3',
    url: 'https://www.apple.com/macbook-pro/',
    title: 'MacBook Pro - Apple',
    description: 'The most powerful MacBook Pro ever is here. With the blazing-fast M2 Pro or M2 Max chip — the most powerful and efficient chip ever in a pro laptop.',
    image: 'https://picsum.photos/seed/macbook/600/400',
    category: 'Product',
    tags: ['apple', 'laptop', 'tech'],
    isFavorite: false,
    isArchived: false,
    notes: 'Check for education pricing before buying.',
  },
    {
    id: '4',
    url: 'https://tailwindcss.com/',
    title: 'Tailwind CSS - Rapidly build modern websites without ever leaving your HTML.',
    description: 'A utility-first CSS framework packed with classes like flex, pt-4, text-center and rotate-90 that can be composed to build any design, directly in your markup.',
    image: 'https://picsum.photos/seed/tailwind/600/400',
    category: 'Article',
    tags: ['css', 'frontend', 'design'],
    isFavorite: false,
    isArchived: true,
    notes: '',
  },
];
