
import React, { useState, useEffect, useMemo } from 'react';
import { LinkItem, Category, Filter } from './types';
import { initialLinks, INITIAL_CATEGORIES, FILTERS } from './constants';
import { fetchMetadata } from './services/metadataService';
import { generateTagsAndCategory } from './services/geminiService';
import Header from './components/Header';
import LinkInputForm from './components/LinkInputForm';
import Toolbar from './components/Toolbar';
import LinkList from './components/LinkList';
import AnalyticsModal from './components/AnalyticsModal';
import EditCategoryModal from './components/EditCategoryModal';
import EditNotesModal from './components/EditNotesModal';
import ManageCategoriesModal from './components/ManageCategoriesModal';

const App: React.FC = () => {
  const [links, setLinks] = useState<LinkItem[]>([]);
  const [categories, setCategories] = useState<Category[]>(INITIAL_CATEGORIES);
  const [appName, setAppName] = useState('LinkStash');
  const [isDarkMode, setIsDarkMode] = useState(false);

  const [isLoading, setIsLoading] = useState(false);
  const [activeFilter, setActiveFilter] = useState<Filter | string>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  
  // Modal states
  const [isAnalyticsOpen, setIsAnalyticsOpen] = useState(false);
  const [isManageCategoriesOpen, setIsManageCategoriesOpen] = useState(false);
  const [editingCategoryLink, setEditingCategoryLink] = useState<LinkItem | null>(null);
  const [editingNotesLink, setEditingNotesLink] = useState<LinkItem | null>(null);

  // Load data from localStorage on initial render
  useEffect(() => {
    try {
      const savedLinks = localStorage.getItem('savedLinks');
      const savedCategories = localStorage.getItem('savedCategories');
      const savedAppName = localStorage.getItem('appName');
      const savedDarkMode = localStorage.getItem('darkMode');

      if (savedLinks) setLinks(JSON.parse(savedLinks));
      else setLinks(initialLinks);
      
      if (savedCategories) setCategories(JSON.parse(savedCategories));
      if (savedAppName) setAppName(JSON.parse(savedAppName));
      if (savedDarkMode) setIsDarkMode(JSON.parse(savedDarkMode));

    } catch (error) {
        console.error("Failed to load data from localStorage", error);
        setLinks(initialLinks);
        setCategories(INITIAL_CATEGORIES);
    }
  }, []);

  // Save data to localStorage when it changes
  useEffect(() => { localStorage.setItem('savedLinks', JSON.stringify(links)); }, [links]);
  useEffect(() => { localStorage.setItem('savedCategories', JSON.stringify(categories)); }, [categories]);
  useEffect(() => { localStorage.setItem('appName', JSON.stringify(appName)); }, [appName]);
  useEffect(() => {
    localStorage.setItem('darkMode', JSON.stringify(isDarkMode));
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  const handleAddLink = async (url: string) => {
    if (links.some(link => link.url === url)) {
      alert("This link has already been saved.");
      return;
    }
    setIsLoading(true);
    try {
      const metadata = await fetchMetadata(url);
      const { category, tags } = await generateTagsAndCategory(url, categories);
      
      const finalCategory = category || 'Other';

      const newLink: LinkItem = {
        id: new Date().toISOString(),
        url,
        ...metadata,
        category: finalCategory,
        tags,
        isFavorite: false,
        isArchived: false,
        notes: '',
      };
      
      setLinks(prevLinks => [newLink, ...prevLinks]);
      
      if (!categories.includes(finalCategory) && finalCategory !== 'Other') {
        setCategories(prev => [...prev, finalCategory]);
      }

    } catch (error) {
      console.error("Failed to add link:", error);
      alert("Sorry, there was an error saving this link. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  // Handle incoming shares from PWA share target
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const sharedUrl = urlParams.get('url');
    const sharedText = urlParams.get('text');
    let linkToSave: string | null = null;

    // The 'url' param is the most likely candidate.
    // The 'text' param can also contain a URL, which is a common fallback.
    const urlToParse = sharedUrl || sharedText;

    if (urlToParse) {
        // A simple regex to find a URL within the shared text.
        const urlRegex = /https?:\/\/[^\s]+/;
        const match = urlToParse.match(urlRegex);
        if (match) {
            linkToSave = match[0];
        }
    }

    if (linkToSave) {
      console.log('Shared link detected:', linkToSave);
      // Use a brief timeout to ensure the UI is responsive before kicking off the async operations.
      setTimeout(() => handleAddLink(linkToSave!), 100);

      // Clean the URL's query params to prevent re-adding on refresh.
      window.history.replaceState({}, document.title, window.location.pathname);
    }
  }, []); // Run only on initial mount.


  const handleDeleteLink = (id: string) => {
    if (window.confirm("Are you sure you want to delete this link?")) {
      setLinks(links.filter(link => link.id !== id));
    }
  };
  
  const handleToggleFavorite = (id: string) => {
    setLinks(links.map(link => link.id === id ? { ...link, isFavorite: !link.isFavorite } : link));
  };
  
  const handleToggleArchive = (id: string) => {
    setLinks(links.map(link => link.id === id ? { ...link, isArchived: !link.isArchived } : link));
  };

  const handleSaveCategory = (linkId: string, newCategory: Category) => {
    setLinks(links.map(link => link.id === linkId ? { ...link, category: newCategory } : link));
    setEditingCategoryLink(null);
  };
  
  const handleAddNewCategory = (newCategory: Category) => {
      if(!categories.includes(newCategory)) {
          setCategories(prev => [...prev, newCategory]);
      }
  };
  
  const handleUpdateCategories = (newCategories: Category[]) => {
      const deletedCategories = categories.filter(c => !newCategories.includes(c));
      if (deletedCategories.length > 0) {
          setLinks(prevLinks => prevLinks.map(link => 
              deletedCategories.includes(link.category) ? { ...link, category: 'Other' } : link
          ));
      }
      setCategories(newCategories);
  };

  const handleSaveNotes = (linkId: string, newNotes: string) => {
      setLinks(links.map(link => link.id === linkId ? { ...link, notes: newNotes } : link));
      setEditingNotesLink(null);
  }

  const handleExportData = () => {
    const dataStr = JSON.stringify({ appName, links, categories });
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    const exportFileDefaultName = 'linkstash_backup.json';
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
  };
  
  const handleImportData = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const text = e.target?.result;
        const data = JSON.parse(text as string);
        if (data.links && data.categories && data.appName) {
          if (window.confirm("This will overwrite your current data. Are you sure?")) {
            setLinks(data.links);
            setCategories(data.categories);
            setAppName(data.appName);
            alert("Data imported successfully!");
          }
        } else {
          alert("Invalid file format.");
        }
      } catch (error) {
        alert("Error importing file.");
        console.error("Import error:", error);
      }
    };
    reader.readAsText(file);
    // Reset file input value to allow importing the same file again
    event.target.value = '';
  };

  const filteredLinks = useMemo(() => {
    let tempLinks = links;

    switch (activeFilter) {
      case 'Favorites':
        tempLinks = tempLinks.filter(link => link.isFavorite && !link.isArchived);
        break;
      case 'Archive':
        tempLinks = tempLinks.filter(link => link.isArchived);
        break;
      case 'All':
         tempLinks = tempLinks.filter(link => !link.isArchived);
        break;
      default:
        // Handle custom category filters
        tempLinks = tempLinks.filter(link => !link.isArchived && link.category === activeFilter);
        break;
    }
    
    if (searchQuery) {
      const lowercasedQuery = searchQuery.toLowerCase();
      tempLinks = tempLinks.filter(link =>
        link.title.toLowerCase().includes(lowercasedQuery) ||
        link.description.toLowerCase().includes(lowercasedQuery) ||
        link.tags.some(tag => tag.toLowerCase().includes(lowercasedQuery)) ||
        link.category.toLowerCase().includes(lowercasedQuery) ||
        (link.notes && link.notes.toLowerCase().includes(lowercasedQuery)) ||
        link.url.toLowerCase().includes(lowercasedQuery)
      );
    }

    return tempLinks;
  }, [links, activeFilter, searchQuery]);
  
  const analyticsData = useMemo(() => {
    const activeLinks = links.filter(l => !l.isArchived);
    const byCategory = activeLinks.reduce((acc, link) => {
      acc[link.category] = (acc[link.category] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    return {
      total: links.length,
      favorites: links.filter(l => l.isFavorite && !l.isArchived).length,
      archived: links.filter(l => l.isArchived).length,
      byCategory,
    };
  }, [links]);

  return (
    <div className="bg-slate-100 dark:bg-slate-900 min-h-screen font-sans text-slate-800 dark:text-slate-200">
      <Header 
        appName={appName}
        onAppNameChange={setAppName}
        isDarkMode={isDarkMode}
        onToggleDarkMode={() => setIsDarkMode(!isDarkMode)}
        onManageCategories={() => setIsManageCategoriesOpen(true)}
        onExport={handleExportData}
        onImport={handleImportData}
      />
      <main className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <LinkInputForm onAddLink={handleAddLink} isLoading={isLoading} />
          <Toolbar
            filters={[...FILTERS, ...categories.filter(c => !FILTERS.includes(c as any))]}
            activeFilter={activeFilter}
            onSelectFilter={setActiveFilter}
            searchQuery={searchQuery}
            onSearchChange={setSearchQuery}
            viewMode={viewMode}
            onViewModeChange={setViewMode}
            onOpenAnalytics={() => setIsAnalyticsOpen(true)}
          />
          <LinkList
            links={filteredLinks}
            onDelete={handleDeleteLink}
            onToggleFavorite={handleToggleFavorite}
            onToggleArchive={handleToggleArchive}
            onEditCategory={(id) => setEditingCategoryLink(links.find(l => l.id === id) || null)}
            onEditNotes={(id) => setEditingNotesLink(links.find(l => l.id === id) || null)}
            isLoading={isLoading && links.length === 0}
            viewMode={viewMode}
            activeFilter={activeFilter}
          />
        </div>
      </main>

      {isAnalyticsOpen && <AnalyticsModal data={analyticsData} onClose={() => setIsAnalyticsOpen(false)} />}
      {isManageCategoriesOpen && <ManageCategoriesModal initialCategories={categories} onSave={handleUpdateCategories} onClose={() => setIsManageCategoriesOpen(false)} />}
      {editingCategoryLink && (
        <EditCategoryModal 
            link={editingCategoryLink}
            categories={categories}
            onClose={() => setEditingCategoryLink(null)}
            onSave={handleSaveCategory}
            onAddNewCategory={handleAddNewCategory}
        />
      )}
      {editingNotesLink && (
          <EditNotesModal 
            link={editingNotesLink}
            onClose={() => setEditingNotesLink(null)}
            onSave={handleSaveNotes}
          />
      )}
    </div>
  );
};

export default App;
