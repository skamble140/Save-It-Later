
// In a real-world application, this would be a server-side function
// that fetches the URL, parses the HTML for meta tags (og:title, etc.),
// and returns the data. This avoids CORS issues.
// For this frontend-only demo, we'll simulate the behavior.

interface Metadata {
    title: string;
    description: string;
    image: string;
}

const getDomainName = (url: string): string => {
    try {
        const hostname = new URL(url).hostname;
        // remove 'www.'
        return hostname.replace(/^www\./, '');
    } catch (e) {
        return "link";
    }
}

export const fetchMetadata = (url: string): Promise<Metadata> => {
    return new Promise((resolve) => {
        // Simulate network delay
        setTimeout(() => {
            const domain = getDomainName(url);
            const metadata: Metadata = {
                title: `Title for: ${domain}`,
                description: `This is a simulated description for the content found at ${url}. In a real app, this would be scraped from the page's meta tags.`,
                image: `https://picsum.photos/seed/${encodeURIComponent(domain)}/600/400`,
            };
            resolve(metadata);
        }, 1000);
    });
};
