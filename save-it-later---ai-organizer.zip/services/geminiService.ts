import { GoogleGenAI, Type } from "@google/genai";
import { Category } from '../types';

if (!process.env.API_KEY) {
  // In a real app, you'd want to handle this more gracefully.
  // For this project, we assume the API key is provided.
  console.warn("API_KEY environment variable not set. Gemini API calls will fail.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });

const schema = {
  type: Type.OBJECT,
  properties: {
    category: {
      type: Type.STRING,
      description: 'The category for this link.',
    },
    tags: {
      type: Type.ARRAY,
      description: 'Generate 3 to 5 relevant keywords or tags for this link.',
      items: {
        type: Type.STRING,
      },
    },
  },
  required: ['category', 'tags'],
};

export const generateTagsAndCategory = async (url: string, categories: Category[]): Promise<{ category: Category; tags: string[] }> => {
  try {
    const prompt = `Analyze the content of the following URL.
Provide a category and relevant tags.
URL: ${url}
Available categories: ${categories.join(', ')}.
Please categorize the link into one of the available categories. If none are a good fit, you may suggest a new, relevant category or use 'Other'.`;
    
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: schema,
      },
    });

    const jsonString = response.text.trim();
    const parsedData = JSON.parse(jsonString);

    if (!parsedData.category || !Array.isArray(parsedData.tags)) {
      throw new Error("Invalid data structure from AI.");
    }
    
    return {
        category: parsedData.category as Category,
        tags: parsedData.tags,
    };

  } catch (error) {
    console.error("Error calling Gemini API:", error);
    // Fallback in case of API error
    return {
      category: 'Other',
      tags: ['untagged'],
    };
  }
};
